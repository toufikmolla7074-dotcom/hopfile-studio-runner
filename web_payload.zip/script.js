document.getElementById('alert-btn').addEventListener('click', function() {
    alert('System is running beautifully. Build APK to run natively on mobile!');
    console.log('Action btn click verified.');
});